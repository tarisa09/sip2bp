﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsPerpustakaan
{
    class Peminjamann : Connection
    {

        public String id_peminjaman { get; set; }
        public String tgl_peminjaman { get; set; }
        public String kode_anggota { get; set; }
        public String kode_buku { get; set; }
        //public int id_admin { get; set; }

        MySqlConnection conn;
        MySqlCommand cmd;

        public Peminjamann()
        {
            conn = new MySqlConnection(conString);
            cmd = new MySqlCommand();

        }

        public String Insert(String id_peminjaman, String tgl_peminjaman, String kode_anggota, String Kode_buku)
        {
            String error = null;
            //membuka koneksi ke database melalui objek conn
            conn.Open();
            //membuat objek command sql yang dihubungkan dengan koneksi database melalui objek conn (menghubungkan objek sql command dengan database)
            cmd = conn.CreateCommand();
            //membuat sql statement
            cmd.CommandText = "INSERT INTO peminjaman (id_peminjaman, tgl_peminjaman, kode_anggota, kode_buku)" +
                "VALUES (@id_peminjaman,@tgl_peminjaman,@kode_anggota,@kode_buku)";
            cmd.Parameters.AddWithValue("@id_peminjaman", id_peminjaman);
            cmd.Parameters.AddWithValue("@tgl_peminjaman", tgl_peminjaman);
            cmd.Parameters.AddWithValue("@kode_anggota", kode_anggota);
            cmd.Parameters.AddWithValue("@kode_buku", kode_buku);
            //cmd.Parameters.AddWithValue("@id_admin", id_admin);

            try
            {
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                error = e.Message;
            }

            return error;
        }

        public DataTable ReadAll()
        {
            DataTable dt = new DataTable();
            //cara 1
            using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM peminjaman", conn))
            {
                //sebaiknya pakai blok try catch
                conn.Open();
                MySqlDataReader rdr = cmd.ExecuteReader();
                dt.Load(rdr);
            }

            /*cara2
            conn.Open();
            cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT * FROM tbpegawai";
            {
                //sebaiknya pakai blok try catch
                MySqlDataReader rdr = cmd.ExecuteReader();
                dt.Load(rdr);
            }
            */

            return dt;
        }
        public string Update()
        {
            string result = null;
            conn.Open();
            cmd = conn.CreateCommand();
            cmd.CommandText = "UPDATE peminjaman set id_peminjaman=@id_peminjaman, tgl_peminjaman=@tgl_peminjaman, kode_anggota=@kode_anggota, kode_buku=@kode_buku," +
                "tgl_peminjaman=@tgl_peminjaman, kode_anggota=@kode_anggota, kode_buku=@kode_buku WHERE id_peminjaman=@id_peminjaman";
            cmd.Parameters.AddWithValue("@id_peminjaman", this.id_peminjaman);
            cmd.Parameters.AddWithValue("@tgl_peminjaman", this.tgl_peminjaman);
            cmd.Parameters.AddWithValue("@kode_anggota", this.kode_anggota);
            cmd.Parameters.AddWithValue("@kode_buku", this.kode_buku);
            try
            {
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                return e.Message;
            }
            return result;
        }
        public string Delete()
        {
            string result = null;
            conn.Open();
            using (MySqlCommand cmd = new MySqlCommand("DELETE FROM peminjaman WHERE id_peminjaman=@id_peminjaman ", conn))
            {
                cmd.Parameters.AddWithValue("@id_peminjaman", this.id_peminjaman);
                try
                {
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
                catch (Exception e)
                {
                    return e.Message;
                }
            }
            return result;
        }
    }
}

