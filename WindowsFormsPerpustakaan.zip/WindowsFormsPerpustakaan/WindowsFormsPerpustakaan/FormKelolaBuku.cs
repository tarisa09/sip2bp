﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsPerpustakaan
{
    public partial class FormKelolaBuku : Form
    {
        String kode_buku, judul_buku, pengarang, penerbit, tahun;
        public FormKelolaBuku()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedrowindex = dataGridViewDataBuku.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = dataGridViewDataBuku.Rows[selectedrowindex];

            textBox5.Text = Convert.ToString(selectedRow.Cells["judul_buku"].Value);
            textBox4.Text = Convert.ToString(selectedRow.Cells["pengarang"].Value);
            textBox3.Text = Convert.ToString(selectedRow.Cells["penerbit"].Value);
            textBox2.Text = Convert.ToString(selectedRow.Cells["tahun"].Value);
            //textBox1.Text = Convert.ToString(selectedRow.Cells["id_admin"].Value);
            kode_buku = Convert.ToString(selectedRow.Cells["kode_buku"].Value);
        }

       Buku dataBuku = new Buku();

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
                string response;
                Buku dataBuku = new Buku();
                dataBuku.kode_buku = textBox1.Text;
                dataBuku.judul_buku = textBox2.Text;
                dataBuku.pengarang= textBox3.Text;
                dataBuku.penerbit = textBox4.Text;
                dataBuku.tahun = textBox5.Text;
                response = dataBuku.Update();
                if (response == null) MessageBox.Show("Sukses");
                else MessageBox.Show(response);
                
            }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            string response;
            Buku dataBuku = new Buku();
            dataBuku.kode_buku = kode_buku;
            response = dataBuku.Delete();
            if (response == null) MessageBox.Show("Sukses");
            else MessageBox.Show(response);
        }

        private void buttonSimpan_Click_1(object sender, EventArgs e)
        {
            Buku dataBuku = new Buku();
            dataBuku.kode_buku = textBox1.Text;
            dataBuku.judul_buku = textBox2.Text;
            dataBuku.pengarang = textBox3.Text;
            dataBuku.penerbit = textBox4.Text;
            dataBuku.tahun = textBox5.Text;
            //dataBuku.id_admin = textBox1.Text;

            //tampilkan data menggunakan message box -> sbg pengganti penyimpanan data ke db
            MessageBox.Show("judul_buku " + dataBuku.judul_buku);

            //menampilkan pada data di gridview
            daftarBuku.Add(dataBuku);
            DataTable dt = new DataTable();
            dataGridViewDataBuku.DataSource = null;
            dataGridViewDataBuku.DataSource = daftarBuku;

            //insert ke database
            String response;
            response = dataBuku.Insert(dataBuku.kode_buku, dataBuku.judul_buku, dataBuku.pengarang, dataBuku.penerbit, dataBuku.tahun);
            if (response == null) MessageBox.Show("Insert data sukses");
            else MessageBox.Show("Insert data gagal " + response);
        }

        System.Collections.ArrayList DaftarBuku = new ArrayList();
        ArrayList daftarBuku = new System.Collections.ArrayList();
        private void FormKelolaBuku_Load(object sender, EventArgs e)
        {

        }
    }
}
