﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsPerpustakaan
{
    public partial class FormPeminjaman : Form
    {
        String id_peminjaman, tgl_peminjaman, kode_anggota, kode_buku;

        private void dataGridViewDataPeminjaman_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedrowindex = dataGridViewDataPeminjaman.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = dataGridViewDataPeminjaman.Rows[selectedrowindex];

            textBoxtglpeminjaman.Text = Convert.ToString(selectedRow.Cells["tgl_peminjaman"].Value);
            textBoxkodeanggota.Text = Convert.ToString(selectedRow.Cells["kode_anggota"].Value);
            textBoxkodebuku.Text = Convert.ToString(selectedRow.Cells["kode_buku"].Value);
            //textBoxTglPeminjaman.Text = Convert.ToString(selectedRow.Cells["id_admin"].Value);
            id_peminjaman = Convert.ToString(selectedRow.Cells["id_peminjaman"].Value);
        }

        public FormPeminjaman()
        {
            InitializeComponent();
        }

        Peminjamann dataPeminjaman = new Peminjamann();

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            string response;
            Peminjamann dataPeminjaman = new Peminjamann();
            dataPeminjaman.id_peminjaman = textBoxidpeminjaman.Text;
            dataPeminjaman.tgl_peminjaman = textBoxtglpeminjaman.Text;
            dataPeminjaman.kode_anggota = textBoxkodeanggota.Text;
            dataPeminjaman.kode_buku = textBoxkodebuku.Text;
            response = dataPeminjaman.Update();
            if (response == null) MessageBox.Show("Sukses");
            else MessageBox.Show(response);
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            string response;
            Peminjamann dataPeminjaman = new Peminjamann();
            dataPeminjaman.id_peminjaman = id_peminjaman;
            response = dataPeminjaman.Delete();
            if (response == null) MessageBox.Show("Sukses");
            else MessageBox.Show(response);
        }

        System.Collections.ArrayList DaftarPeminjaman = new ArrayList();
        ArrayList daftarPeminjaman = new System.Collections.ArrayList();

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            Peminjamann dataPeminjaman = new Peminjamann();
            dataPeminjaman.id_peminjaman = textBoxidpeminjaman.Text;
            dataPeminjaman.tgl_peminjaman = textBoxtglpeminjaman.Text;
            dataPeminjaman.kode_anggota = textBoxkodeanggota.Text;
            dataPeminjaman.kode_buku = textBoxkodebuku.Text;

            //tampilkan data menggunakan message box -> sbg pengganti penyimpanan data ke db
            MessageBox.Show("id_peminjaman " + dataPeminjaman.id_peminjaman);

            //menampilkan pada data di gridview
            daftarPeminjaman.Add(dataPeminjaman);
            DataTable dt = new DataTable();
            dataGridViewDataPeminjaman.DataSource = null;
            dataGridViewDataPeminjaman.DataSource = daftarPeminjaman;

            //insert ke database
            String response;
            response = dataPeminjaman.Insert(dataPeminjaman.id_peminjaman, dataPeminjaman.tgl_peminjaman, dataPeminjaman.kode_anggota, dataPeminjaman.kode_buku);
            if (response == null) MessageBox.Show("Insert data sukses");
            else MessageBox.Show("Insert data gagal " + response);
        }
    }
}
