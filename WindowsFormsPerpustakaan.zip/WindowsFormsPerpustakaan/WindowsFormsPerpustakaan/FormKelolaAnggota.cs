﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsPerpustakaan
{
    public partial class EntryDataAnggota : Form
    {

        //variable
        String kode_anggota, nama_anggota, kelas, alamat_anggota;

        Anggota dataAnggota = new Anggota();
        System.Collections.ArrayList DaftarAnggota = new ArrayList();

        private void textBoxKodeAnggota_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedrowindex = dataGridViewEntryDataAnggota.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = dataGridViewEntryDataAnggota.Rows[selectedrowindex];

            textBoxNamaAnggota.Text = Convert.ToString(selectedRow.Cells["nama_anggota"].Value);
            textBoxKelas.Text = Convert.ToString(selectedRow.Cells["kelas"].Value);
            textBoxAlamat.Text = Convert.ToString(selectedRow.Cells["alamat_anggota"].Value);
            kode_anggota = Convert.ToString(selectedRow.Cells["kode_anggota"].Value);
        }

        private void EntryDataAnggota_Load(object sender, EventArgs e)
        {

        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            string response;
            Anggota dataAnggota = new Anggota();
            dataAnggota.kode_anggota = textBoxKodeAnggota.Text;
            dataAnggota.nama_anggota = textBoxNamaAnggota.Text;
            dataAnggota.kelas = textBoxKelas.Text;
            dataAnggota.alamat_anggota = textBoxAlamat.Text;
            response = dataAnggota.Update();
            if (response == null) MessageBox.Show("Sukses");
            else MessageBox.Show(response);
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            string response;
            Anggota dataAnggota = new Anggota();
            dataAnggota.kode_anggota = kode_anggota;
            response = dataAnggota.Delete();
            if (response == null) MessageBox.Show("Sukses");
            else MessageBox.Show(response);
            
        }

        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            Anggota dataAnggota = new Anggota();

            dataAnggota.kode_anggota = textBoxKodeAnggota.Text;
            dataAnggota.nama_anggota = textBoxNamaAnggota.Text;
            dataAnggota.kelas = textBoxKelas.Text;
            dataAnggota.alamat_anggota = textBoxAlamat.Text;

            //tampilkan data menggunakan message box -> sbg pengganti penyimpanan data ke db
            MessageBox.Show("nama_anggota " + dataAnggota.nama_anggota);

            //menampilkan pada data di gridview
            daftarAnggota.Add(dataAnggota);
            DataTable dt = new DataTable();
            dataGridViewEntryDataAnggota.DataSource = null;
            dataGridViewEntryDataAnggota.DataSource = daftarAnggota;

            //insert ke database
            String response;
            response = dataAnggota.Insert(dataAnggota.kode_anggota, dataAnggota.nama_anggota, dataAnggota.kelas, dataAnggota.alamat_anggota);
            if (response == null) MessageBox.Show("Insert data sukses");
            else MessageBox.Show("Insert data gagal " + response);
        }

        public EntryDataAnggota()
        {
            InitializeComponent();
        }


        ArrayList daftarAnggota = new System.Collections.ArrayList();

 

    }
}
