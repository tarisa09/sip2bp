﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsPerpustakaan
{
    class Pengembalian : Connection
    {
        public string id_peminjaman { get; set; }
        public String Id_pengembalian { get; set; }
        public String tgl_pengembalian { get; set; }

        MySqlConnection conn;
        MySqlCommand cmd;

        public Pengembalian()
        {
            conn = new MySqlConnection(conString);
            cmd = new MySqlCommand();

        }

        public String Insert(String id_pengambalian, String tgl_pengembalian, String id_peminjaman)
        {
            String error = null;
            //membuka koneksi ke database melalui objek conn
            conn.Open();
            //membuat objek command sql yang dihubungkan dengan koneksi database melalui objek conn (menghubungkan objek sql command dengan database)
            cmd = conn.CreateCommand();
            //membuat sql statement
            cmd.CommandText = "INSERT INTO pengembalian (id_pengembalian, tgl_pengembalian, id_peminjaman)" +
                "VALUES (@id_pengembalian, @tgl_pengembalian, @id_peminjaman)";
            cmd.Parameters.AddWithValue("@id_pengembalian", Id_pengembalian);
            cmd.Parameters.AddWithValue("@tgl_pengembalian", tgl_pengembalian);
            cmd.Parameters.AddWithValue("@id_peminjaman", id_peminjaman);
            //cmd.Parameters.AddWithValue("@id_admin", id_admin);

            try
            {
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                error = e.Message;
            }

            return error;
        }

        public DataTable ReadAll()
        {
            DataTable dt = new DataTable();
            //cara 1
            using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM pengembalian", conn))
            {
                //sebaiknya pakai blok try catch
                conn.Open();
                MySqlDataReader rdr = cmd.ExecuteReader();
                dt.Load(rdr);
            }

            /*cara2
            conn.Open();
            cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT * FROM tbpegawai";
            {
                //sebaiknya pakai blok try catch
                MySqlDataReader rdr = cmd.ExecuteReader();
                dt.Load(rdr);
            }
            */

            return dt;
        }
        public string Update()
        {
            string result = null;
            conn.Open();
            cmd = conn.CreateCommand();
            cmd.CommandText = "UPDATE pengembalian set Id_pengembalian=@Id_pengembalian,tgl_pengembalian=@tgl_pengembalian,id_peminjaman=@id_peminjaman," +
                "id_peminjaman=@id_peminjaman,tgl_pengembalian=@tgl_pengembalian WHERE Id_pengembalian=@Id_pengembalian";
            cmd.Parameters.AddWithValue("@id_pengembalian", Id_pengembalian);
            cmd.Parameters.AddWithValue("@tgl_pengembalian", tgl_pengembalian);
            cmd.Parameters.AddWithValue("@id_peminjaman", id_peminjaman);
            try
            {
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                return e.Message;
            }
            return result;
        }
        public string Delete()
        {
            string result = null;
            conn.Open();
            using (MySqlCommand cmd = new MySqlCommand("DELETE FROM pengembalian  WHERE Id_pengembalian=@Id_pengembalian ", conn))
            {
                cmd.Parameters.AddWithValue("@Id_pengembalian", this.Id_pengembalian);
                try
                {
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
                catch (Exception e)
                {
                    return e.Message;
                }
            }
            return result;
        }
    }
}
