﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsPerpustakaan
{
    //variable
   
    public partial class FormPengembalian : Form
    {
        String Id_pengembalian, tgl_pengembalian, id_peminjaman;
        public FormPengembalian()
        {
            InitializeComponent();
        }

        Pengembalian dataPengembalian = new Pengembalian();

        System.Collections.ArrayList DaftarPengembalian = new ArrayList();

        ArrayList daftarPengembalian = new System.Collections.ArrayList();
        private void buttonSimpan_Click(object sender, EventArgs e)
        {
            Pengembalian dataPengembalian = new Pengembalian();
            dataPengembalian.Id_pengembalian = textBoxid_pengembalian.Text;
            dataPengembalian.tgl_pengembalian = textBoxTglPengembalian.Text;
            dataPengembalian.id_peminjaman = textBoxId_Peminjaman.Text;

            //tampilkan data menggunakan message box -> sbg pengganti penyimpanan data ke db
            MessageBox.Show("Id_pengembalian " + dataPengembalian.Id_pengembalian);

            //menampilkan pada data di gridview
            daftarPengembalian.Add(dataPengembalian);
            DataTable dt = new DataTable();
            dataGridViewEntryDataPengembalian.DataSource = null;
            dataGridViewEntryDataPengembalian.DataSource = daftarPengembalian;

            //insert ke database
            String response;
            response = dataPengembalian.Insert(dataPengembalian.Id_pengembalian, dataPengembalian.tgl_pengembalian, dataPengembalian.id_peminjaman);
            if (response == null) MessageBox.Show("Insert data sukses");
            else MessageBox.Show("Insert data gagal " + response);
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            string response;
            Pengembalian dataPengembalian = new Pengembalian();
            dataPengembalian.Id_pengembalian = textBoxid_pengembalian.Text;
            dataPengembalian.tgl_pengembalian = textBoxTglPengembalian.Text;
            dataPengembalian.id_peminjaman = textBoxId_Peminjaman.Text;
            response = dataPengembalian.Update();
            if (response == null) MessageBox.Show("Sukses");
            else MessageBox.Show(response);
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            string response;
            Pengembalian dataPengembalian = new Pengembalian();
            dataPengembalian.id_peminjaman= id_peminjaman;
            response = dataPengembalian.Delete();
            if (response == null) MessageBox.Show("Sukses");
            else MessageBox.Show(response);
        }

        private void dataGridViewEntryDataPengembalian_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedrowindex = dataGridViewEntryDataPengembalian.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = dataGridViewEntryDataPengembalian.Rows[selectedrowindex];
            textBoxTglPengembalian.Text = Convert.ToString(selectedRow.Cells["tgl_pengembalian"].Value);
            textBoxId_Peminjaman.Text = Convert.ToString(selectedRow.Cells["id_peminjaman"].Value);
            Id_pengembalian = Convert.ToString(selectedRow.Cells["id_pengembalian"].Value);
        }

        private void textBoxid_pengembalian_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
