﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsPerpustakaan
{
    class Anggota : Connection
    {
            //public int kode_anggota { get; set; }
            public String kode_anggota { set; get; }
            public String nama_anggota { set; get; }
            public String kelas { set; get; }
            public String alamat_anggota { set; get; }


            MySqlConnection conn;
            MySqlCommand cmd;

            public Anggota()
            {
                conn = new MySqlConnection(conString);
                cmd = new MySqlCommand();

            }

            public String Insert(String kode_anggota, String nama_anggota, String kelas, String alamat_anggota)
            {
                String error = null;
                //membuka koneksi ke database melalui objek conn
                conn.Open();
                //membuat objek command sql yang dihubungkan dengan koneksi database melalui objek conn (menghubungkan objek sql command dengan database)
                cmd = conn.CreateCommand();
                //membuat sql statement
                cmd.CommandText = "INSERT INTO anggota (kode_anggota, nama_anggota, kelas, alamat_anggota)" +
                    "VALUES (@kode_anggota, @nama_anggota,@kelas,@alamat_anggota)";
                cmd.Parameters.AddWithValue("@kode_anggota", kode_anggota);
                cmd.Parameters.AddWithValue("@nama_anggota", nama_anggota);
                cmd.Parameters.AddWithValue("@kelas", kelas);
                cmd.Parameters.AddWithValue("@alamat_anggota", alamat_anggota);
                // cmd.Parameters.AddWithValue("@id_admin", id_admin);

                try
                {
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
                catch (Exception e)
                {
                    error = e.Message;
                }

                return error;
            }

            public DataTable ReadAll()
            {
                DataTable dt = new DataTable();
                //cara 1
                using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM anggota", conn))
                {
                    //sebaiknya pakai blok try catch
                    conn.Open();
                    MySqlDataReader rdr = cmd.ExecuteReader();
                    dt.Load(rdr);
                }

                /*cara2
                conn.Open();
                cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT * FROM tbpegawai";
                {
                    //sebaiknya pakai blok try catch
                    MySqlDataReader rdr = cmd.ExecuteReader();
                    dt.Load(rdr);
                }
                */

                return dt;
            }
        public string Update()
        {
            string result = null;
            conn.Open();
            cmd = conn.CreateCommand();
            cmd.CommandText = "UPDATE anggota set kode_anggota=@kode_anggota, nama_anggota=@nama_anggota," +
                "kelas=@kelas, alamat_anggota=@alamat_anggota WHERE kode_anggota=@kode_anggota ";
            cmd.Parameters.AddWithValue("@kode_anggota", this.kode_anggota);
            cmd.Parameters.AddWithValue("@nama_anggota", this.nama_anggota);
            cmd.Parameters.AddWithValue("@kelas", this.kelas);
            cmd.Parameters.AddWithValue("@alamat_anggota", this.alamat_anggota);
            try
            {
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                return e.Message;
            }
            return result;
        }
        public string Delete()
        {
            string result = null;
            conn.Open();
            using (MySqlCommand cmd = new MySqlCommand("DELETE FROM anggota WHERE kode_anggota=@kode_anggota ", conn))
            {
                cmd.Parameters.AddWithValue("@kode_anggota", this.kode_anggota);
                try
                {
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
                catch (Exception e)
                {
                    return e.Message;
                }
            }
            return result;
        }
    }
}

