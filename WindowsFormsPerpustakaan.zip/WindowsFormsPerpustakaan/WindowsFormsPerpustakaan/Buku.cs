﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsPerpustakaan
{
    class Buku : Connection
    {
        public String kode_buku { get; set; }
        public String judul_buku { get; set; }
        public String pengarang { get; set; }
        public String penerbit { get; set; }
        public String tahun { get; set; }


        MySqlConnection conn;
        MySqlCommand cmd;

        public Buku()
        {
            conn = new MySqlConnection(conString);
            cmd = new MySqlCommand();

        }

        public String Insert(String kode_buku, String judul_buku, String pengarang, String penerbit, String tahun)
        {
            String error = null;
            //membuka koneksi ke database melalui objek conn
            conn.Open();
            //membuat objek command sql yang dihubungkan dengan koneksi database melalui objek conn (menghubungkan objek sql command dengan database)
            cmd = conn.CreateCommand();
            //membuat sql statement
            cmd.CommandText = "INSERT INTO buku (kode_buku ,judul_buku, pengarang, penerbit, tahun)" +
                "VALUES (@kode_buku,@judul_buku,@pengarang,@penerbit,@tahun)";
            cmd.Parameters.AddWithValue("@kode_buku", kode_buku);
            cmd.Parameters.AddWithValue("@judul_buku", judul_buku);
            cmd.Parameters.AddWithValue("@pengarang", pengarang);
            cmd.Parameters.AddWithValue("@penerbit", penerbit);
            cmd.Parameters.AddWithValue("@tahun", tahun);

            try
            {
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                error = e.Message;
            }

            return error;
        }

        public DataTable ReadAll()
        {
            DataTable dt = new DataTable();
            //cara 1
            using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM buku", conn))
            {
                //sebaiknya pakai blok try catch
                conn.Open();
                MySqlDataReader rdr = cmd.ExecuteReader();
                dt.Load(rdr);
            }

            /*cara2
            conn.Open();
            cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT * FROM tbpegawai";
            {
                //sebaiknya pakai blok try catch
                MySqlDataReader rdr = cmd.ExecuteReader();
                dt.Load(rdr);
            }
            */

            return dt;
        }
        public string Update()
        {
            string result = null;
            conn.Open();
            cmd = conn.CreateCommand();
            cmd.CommandText = "UPDATE buku set kode_buku=@kode_buku, judul_buku=@judul_buku , pengarang=@pengarang," +
                 "penerbit = @penerbit, tahun = @tahun WHERE kode_buku=@kode_buku";
            cmd.Parameters.AddWithValue("@kode_buku", this.kode_buku);
            cmd.Parameters.AddWithValue("@judul_buku", this.judul_buku);
            cmd.Parameters.AddWithValue("@pengarang", this.pengarang);
            cmd.Parameters.AddWithValue("@penerbit", this.penerbit);
            cmd.Parameters.AddWithValue("@tahun", this.tahun);
            try
            {
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                return e.Message;
            }
            return result;
        }
        public string Delete()
        {
            string result = null;
            conn.Open();
            using (MySqlCommand cmd = new MySqlCommand("DELETE FROM buku WHERE kode_buku=@kode_buku ", conn))
            {
                cmd.Parameters.AddWithValue("@kode_buku", this.kode_buku);
                try
                {
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
                catch (Exception e)
                {
                    return e.Message;
                }
            }
            return result;
        }
    }
}
