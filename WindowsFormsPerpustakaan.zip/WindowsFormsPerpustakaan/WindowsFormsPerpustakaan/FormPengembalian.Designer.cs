﻿
namespace WindowsFormsPerpustakaan
{
    partial class FormPengembalian
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxPeminjaman = new System.Windows.Forms.GroupBox();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.buttonSimpan = new System.Windows.Forms.Button();
            this.dataGridViewEntryDataPengembalian = new System.Windows.Forms.DataGridView();
            this.textBoxId_Peminjaman = new System.Windows.Forms.TextBox();
            this.textBoxTglPengembalian = new System.Windows.Forms.TextBox();
            this.textBoxid_pengembalian = new System.Windows.Forms.TextBox();
            this.textboxidPengembalian = new System.Windows.Forms.Label();
            this.labelTanggalPengembalian = new System.Windows.Forms.Label();
            this.labelId_Pengembalian = new System.Windows.Forms.Label();
            this.labelPeminjaman = new System.Windows.Forms.Label();
            this.groupBoxPeminjaman.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEntryDataPengembalian)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxPeminjaman
            // 
            this.groupBoxPeminjaman.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBoxPeminjaman.Controls.Add(this.buttonDelete);
            this.groupBoxPeminjaman.Controls.Add(this.buttonUpdate);
            this.groupBoxPeminjaman.Controls.Add(this.buttonSimpan);
            this.groupBoxPeminjaman.Controls.Add(this.dataGridViewEntryDataPengembalian);
            this.groupBoxPeminjaman.Controls.Add(this.textBoxId_Peminjaman);
            this.groupBoxPeminjaman.Controls.Add(this.textBoxTglPengembalian);
            this.groupBoxPeminjaman.Controls.Add(this.textBoxid_pengembalian);
            this.groupBoxPeminjaman.Controls.Add(this.textboxidPengembalian);
            this.groupBoxPeminjaman.Controls.Add(this.labelTanggalPengembalian);
            this.groupBoxPeminjaman.Controls.Add(this.labelId_Pengembalian);
            this.groupBoxPeminjaman.Location = new System.Drawing.Point(33, 82);
            this.groupBoxPeminjaman.Margin = new System.Windows.Forms.Padding(4);
            this.groupBoxPeminjaman.Name = "groupBoxPeminjaman";
            this.groupBoxPeminjaman.Padding = new System.Windows.Forms.Padding(4);
            this.groupBoxPeminjaman.Size = new System.Drawing.Size(1133, 450);
            this.groupBoxPeminjaman.TabIndex = 4;
            this.groupBoxPeminjaman.TabStop = false;
            this.groupBoxPeminjaman.Text = "Data Pengembalian";
            // 
            // buttonDelete
            // 
            this.buttonDelete.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.buttonDelete.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonDelete.Location = new System.Drawing.Point(232, 151);
            this.buttonDelete.Margin = new System.Windows.Forms.Padding(4);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(100, 39);
            this.buttonDelete.TabIndex = 14;
            this.buttonDelete.Text = "Delete";
            this.buttonDelete.UseVisualStyleBackColor = false;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.buttonUpdate.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonUpdate.Location = new System.Drawing.Point(124, 151);
            this.buttonUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(100, 39);
            this.buttonUpdate.TabIndex = 13;
            this.buttonUpdate.Text = "Update";
            this.buttonUpdate.UseVisualStyleBackColor = false;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // buttonSimpan
            // 
            this.buttonSimpan.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonSimpan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.buttonSimpan.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonSimpan.Location = new System.Drawing.Point(16, 151);
            this.buttonSimpan.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSimpan.Name = "buttonSimpan";
            this.buttonSimpan.Size = new System.Drawing.Size(100, 39);
            this.buttonSimpan.TabIndex = 12;
            this.buttonSimpan.Text = "Simpan";
            this.buttonSimpan.UseVisualStyleBackColor = false;
            this.buttonSimpan.Click += new System.EventHandler(this.buttonSimpan_Click);
            // 
            // dataGridViewEntryDataPengembalian
            // 
            this.dataGridViewEntryDataPengembalian.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEntryDataPengembalian.Location = new System.Drawing.Point(16, 208);
            this.dataGridViewEntryDataPengembalian.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewEntryDataPengembalian.Name = "dataGridViewEntryDataPengembalian";
            this.dataGridViewEntryDataPengembalian.RowHeadersWidth = 51;
            this.dataGridViewEntryDataPengembalian.Size = new System.Drawing.Size(1109, 235);
            this.dataGridViewEntryDataPengembalian.TabIndex = 8;
            this.dataGridViewEntryDataPengembalian.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewEntryDataPengembalian_CellContentClick);
            // 
            // textBoxId_Peminjaman
            // 
            this.textBoxId_Peminjaman.Location = new System.Drawing.Point(189, 106);
            this.textBoxId_Peminjaman.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxId_Peminjaman.Name = "textBoxId_Peminjaman";
            this.textBoxId_Peminjaman.Size = new System.Drawing.Size(920, 22);
            this.textBoxId_Peminjaman.TabIndex = 6;
            // 
            // textBoxTglPengembalian
            // 
            this.textBoxTglPengembalian.Location = new System.Drawing.Point(189, 73);
            this.textBoxTglPengembalian.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxTglPengembalian.Name = "textBoxTglPengembalian";
            this.textBoxTglPengembalian.Size = new System.Drawing.Size(920, 22);
            this.textBoxTglPengembalian.TabIndex = 5;
            // 
            // textBoxid_pengembalian
            // 
            this.textBoxid_pengembalian.Location = new System.Drawing.Point(189, 39);
            this.textBoxid_pengembalian.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxid_pengembalian.Name = "textBoxid_pengembalian";
            this.textBoxid_pengembalian.Size = new System.Drawing.Size(920, 22);
            this.textBoxid_pengembalian.TabIndex = 4;
            this.textBoxid_pengembalian.TextChanged += new System.EventHandler(this.textBoxid_pengembalian_TextChanged);
            // 
            // textboxidPengembalian
            // 
            this.textboxidPengembalian.AutoSize = true;
            this.textboxidPengembalian.Location = new System.Drawing.Point(9, 112);
            this.textboxidPengembalian.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textboxidPengembalian.Name = "textboxidPengembalian";
            this.textboxidPengembalian.Size = new System.Drawing.Size(100, 17);
            this.textboxidPengembalian.TabIndex = 2;
            this.textboxidPengembalian.Text = "Id Peminjaman";
            // 
            // labelTanggalPengembalian
            // 
            this.labelTanggalPengembalian.AutoSize = true;
            this.labelTanggalPengembalian.Location = new System.Drawing.Point(9, 78);
            this.labelTanggalPengembalian.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTanggalPengembalian.Name = "labelTanggalPengembalian";
            this.labelTanggalPengembalian.Size = new System.Drawing.Size(154, 17);
            this.labelTanggalPengembalian.TabIndex = 1;
            this.labelTanggalPengembalian.Text = "Tanggal Pengembalian";
            // 
            // labelId_Pengembalian
            // 
            this.labelId_Pengembalian.AutoSize = true;
            this.labelId_Pengembalian.Location = new System.Drawing.Point(9, 42);
            this.labelId_Pengembalian.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelId_Pengembalian.Name = "labelId_Pengembalian";
            this.labelId_Pengembalian.Size = new System.Drawing.Size(117, 17);
            this.labelId_Pengembalian.TabIndex = 0;
            this.labelId_Pengembalian.Text = "Id_Pengembalian";
            // 
            // labelPeminjaman
            // 
            this.labelPeminjaman.AutoSize = true;
            this.labelPeminjaman.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPeminjaman.Location = new System.Drawing.Point(428, 39);
            this.labelPeminjaman.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPeminjaman.Name = "labelPeminjaman";
            this.labelPeminjaman.Size = new System.Drawing.Size(306, 24);
            this.labelPeminjaman.TabIndex = 5;
            this.labelPeminjaman.Text = "ENTRY DATA PENGEMBALIAN";
            // 
            // FormPengembalian
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1200, 543);
            this.Controls.Add(this.labelPeminjaman);
            this.Controls.Add(this.groupBoxPeminjaman);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormPengembalian";
            this.Text = "FormPengembalian";
            this.groupBoxPeminjaman.ResumeLayout(false);
            this.groupBoxPeminjaman.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEntryDataPengembalian)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxPeminjaman;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.Button buttonSimpan;
        private System.Windows.Forms.DataGridView dataGridViewEntryDataPengembalian;
        private System.Windows.Forms.TextBox textBoxId_Peminjaman;
        private System.Windows.Forms.TextBox textBoxTglPengembalian;
        private System.Windows.Forms.TextBox textBoxid_pengembalian;
        private System.Windows.Forms.Label textboxidPengembalian;
        private System.Windows.Forms.Label labelTanggalPengembalian;
        private System.Windows.Forms.Label labelId_Pengembalian;
        private System.Windows.Forms.Label labelPeminjaman;
    }
}