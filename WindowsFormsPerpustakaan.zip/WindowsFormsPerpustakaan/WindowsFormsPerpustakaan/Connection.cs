﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsPerpustakaan
{
    class Connection
    {
        protected String conString = "server=localhost; database=sip2bp; uid=root; password=";
    }
}
