﻿
namespace WindowsFormsPerpustakaan
{
    partial class FormPeminjaman
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelPeminjaman = new System.Windows.Forms.Label();
            this.groupBoxPeminjaman = new System.Windows.Forms.GroupBox();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.buttonSimpan = new System.Windows.Forms.Button();
            this.dataGridViewDataPeminjaman = new System.Windows.Forms.DataGridView();
            this.textBoxkodebuku = new System.Windows.Forms.TextBox();
            this.textBoxkodeanggota = new System.Windows.Forms.TextBox();
            this.textBoxtglpeminjaman = new System.Windows.Forms.TextBox();
            this.textBoxidpeminjaman = new System.Windows.Forms.TextBox();
            this.labelTanggalPeminjaman = new System.Windows.Forms.Label();
            this.labelKodeBuku = new System.Windows.Forms.Label();
            this.labelKodeAnggota = new System.Windows.Forms.Label();
            this.labelId_Peminjaman = new System.Windows.Forms.Label();
            this.groupBoxPeminjaman.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDataPeminjaman)).BeginInit();
            this.SuspendLayout();
            // 
            // labelPeminjaman
            // 
            this.labelPeminjaman.AutoSize = true;
            this.labelPeminjaman.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPeminjaman.Location = new System.Drawing.Point(473, 31);
            this.labelPeminjaman.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPeminjaman.Name = "labelPeminjaman";
            this.labelPeminjaman.Size = new System.Drawing.Size(280, 24);
            this.labelPeminjaman.TabIndex = 2;
            this.labelPeminjaman.Text = "ENTRY DATA PEMINJAMAN";
            // 
            // groupBoxPeminjaman
            // 
            this.groupBoxPeminjaman.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBoxPeminjaman.Controls.Add(this.buttonDelete);
            this.groupBoxPeminjaman.Controls.Add(this.buttonUpdate);
            this.groupBoxPeminjaman.Controls.Add(this.buttonSimpan);
            this.groupBoxPeminjaman.Controls.Add(this.dataGridViewDataPeminjaman);
            this.groupBoxPeminjaman.Controls.Add(this.textBoxkodebuku);
            this.groupBoxPeminjaman.Controls.Add(this.textBoxkodeanggota);
            this.groupBoxPeminjaman.Controls.Add(this.textBoxtglpeminjaman);
            this.groupBoxPeminjaman.Controls.Add(this.textBoxidpeminjaman);
            this.groupBoxPeminjaman.Controls.Add(this.labelTanggalPeminjaman);
            this.groupBoxPeminjaman.Controls.Add(this.labelKodeBuku);
            this.groupBoxPeminjaman.Controls.Add(this.labelKodeAnggota);
            this.groupBoxPeminjaman.Controls.Add(this.labelId_Peminjaman);
            this.groupBoxPeminjaman.Location = new System.Drawing.Point(33, 68);
            this.groupBoxPeminjaman.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBoxPeminjaman.Name = "groupBoxPeminjaman";
            this.groupBoxPeminjaman.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBoxPeminjaman.Size = new System.Drawing.Size(1133, 450);
            this.groupBoxPeminjaman.TabIndex = 3;
            this.groupBoxPeminjaman.TabStop = false;
            this.groupBoxPeminjaman.Text = "Data Peminjaman";
            // 
            // buttonDelete
            // 
            this.buttonDelete.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.buttonDelete.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonDelete.Location = new System.Drawing.Point(229, 190);
            this.buttonDelete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(100, 39);
            this.buttonDelete.TabIndex = 14;
            this.buttonDelete.Text = "Delete";
            this.buttonDelete.UseVisualStyleBackColor = false;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.buttonUpdate.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonUpdate.Location = new System.Drawing.Point(121, 190);
            this.buttonUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(100, 39);
            this.buttonUpdate.TabIndex = 13;
            this.buttonUpdate.Text = "Update";
            this.buttonUpdate.UseVisualStyleBackColor = false;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // buttonSimpan
            // 
            this.buttonSimpan.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonSimpan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.buttonSimpan.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonSimpan.Location = new System.Drawing.Point(13, 190);
            this.buttonSimpan.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonSimpan.Name = "buttonSimpan";
            this.buttonSimpan.Size = new System.Drawing.Size(100, 39);
            this.buttonSimpan.TabIndex = 12;
            this.buttonSimpan.Text = "Simpan";
            this.buttonSimpan.UseVisualStyleBackColor = false;
            this.buttonSimpan.Click += new System.EventHandler(this.buttonSimpan_Click);
            // 
            // dataGridViewDataPeminjaman
            // 
            this.dataGridViewDataPeminjaman.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDataPeminjaman.Location = new System.Drawing.Point(13, 247);
            this.dataGridViewDataPeminjaman.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridViewDataPeminjaman.Name = "dataGridViewDataPeminjaman";
            this.dataGridViewDataPeminjaman.RowHeadersWidth = 51;
            this.dataGridViewDataPeminjaman.Size = new System.Drawing.Size(1109, 196);
            this.dataGridViewDataPeminjaman.TabIndex = 8;
            this.dataGridViewDataPeminjaman.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDataPeminjaman_CellContentClick);
            // 
            // textBoxkodebuku
            // 
            this.textBoxkodebuku.Location = new System.Drawing.Point(189, 140);
            this.textBoxkodebuku.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxkodebuku.Name = "textBoxkodebuku";
            this.textBoxkodebuku.Size = new System.Drawing.Size(920, 22);
            this.textBoxkodebuku.TabIndex = 7;
            // 
            // textBoxkodeanggota
            // 
            this.textBoxkodeanggota.Location = new System.Drawing.Point(189, 106);
            this.textBoxkodeanggota.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxkodeanggota.Name = "textBoxkodeanggota";
            this.textBoxkodeanggota.Size = new System.Drawing.Size(920, 22);
            this.textBoxkodeanggota.TabIndex = 6;
            // 
            // textBoxtglpeminjaman
            // 
            this.textBoxtglpeminjaman.Location = new System.Drawing.Point(189, 73);
            this.textBoxtglpeminjaman.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxtglpeminjaman.Name = "textBoxtglpeminjaman";
            this.textBoxtglpeminjaman.Size = new System.Drawing.Size(920, 22);
            this.textBoxtglpeminjaman.TabIndex = 5;
            // 
            // textBoxidpeminjaman
            // 
            this.textBoxidpeminjaman.Location = new System.Drawing.Point(189, 39);
            this.textBoxidpeminjaman.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxidpeminjaman.Name = "textBoxidpeminjaman";
            this.textBoxidpeminjaman.Size = new System.Drawing.Size(920, 22);
            this.textBoxidpeminjaman.TabIndex = 4;
            // 
            // labelTanggalPeminjaman
            // 
            this.labelTanggalPeminjaman.AutoSize = true;
            this.labelTanggalPeminjaman.Location = new System.Drawing.Point(8, 76);
            this.labelTanggalPeminjaman.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTanggalPeminjaman.Name = "labelTanggalPeminjaman";
            this.labelTanggalPeminjaman.Size = new System.Drawing.Size(141, 17);
            this.labelTanggalPeminjaman.TabIndex = 3;
            this.labelTanggalPeminjaman.Text = "Tanggal Peminjaman";
            // 
            // labelKodeBuku
            // 
            this.labelKodeBuku.AutoSize = true;
            this.labelKodeBuku.Location = new System.Drawing.Point(10, 143);
            this.labelKodeBuku.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelKodeBuku.Name = "labelKodeBuku";
            this.labelKodeBuku.Size = new System.Drawing.Size(77, 17);
            this.labelKodeBuku.TabIndex = 2;
            this.labelKodeBuku.Text = "Kode Buku";
            // 
            // labelKodeAnggota
            // 
            this.labelKodeAnggota.AutoSize = true;
            this.labelKodeAnggota.Location = new System.Drawing.Point(10, 109);
            this.labelKodeAnggota.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelKodeAnggota.Name = "labelKodeAnggota";
            this.labelKodeAnggota.Size = new System.Drawing.Size(98, 17);
            this.labelKodeAnggota.TabIndex = 1;
            this.labelKodeAnggota.Text = "Kode Anggota";
            // 
            // labelId_Peminjaman
            // 
            this.labelId_Peminjaman.AutoSize = true;
            this.labelId_Peminjaman.Location = new System.Drawing.Point(9, 42);
            this.labelId_Peminjaman.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelId_Peminjaman.Name = "labelId_Peminjaman";
            this.labelId_Peminjaman.Size = new System.Drawing.Size(104, 17);
            this.labelId_Peminjaman.TabIndex = 0;
            this.labelId_Peminjaman.Text = "Id_Peminjaman";
            // 
            // FormPeminjaman
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1200, 543);
            this.Controls.Add(this.groupBoxPeminjaman);
            this.Controls.Add(this.labelPeminjaman);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FormPeminjaman";
            this.Text = "FormPeminjaman";
            this.groupBoxPeminjaman.ResumeLayout(false);
            this.groupBoxPeminjaman.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDataPeminjaman)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelPeminjaman;
        private System.Windows.Forms.GroupBox groupBoxPeminjaman;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.Button buttonSimpan;
        private System.Windows.Forms.DataGridView dataGridViewDataPeminjaman;
        private System.Windows.Forms.TextBox textBoxkodebuku;
        private System.Windows.Forms.TextBox textBoxkodeanggota;
        private System.Windows.Forms.TextBox textBoxtglpeminjaman;
        private System.Windows.Forms.TextBox textBoxidpeminjaman;
        private System.Windows.Forms.Label labelTanggalPeminjaman;
        private System.Windows.Forms.Label labelKodeBuku;
        private System.Windows.Forms.Label labelKodeAnggota;
        private System.Windows.Forms.Label labelId_Peminjaman;
    }
}