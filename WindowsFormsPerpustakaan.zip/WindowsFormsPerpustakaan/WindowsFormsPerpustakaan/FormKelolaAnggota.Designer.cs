﻿
namespace WindowsFormsPerpustakaan
{
    partial class EntryDataAnggota
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelAnggota = new System.Windows.Forms.Label();
            this.groupBoxAnggota = new System.Windows.Forms.GroupBox();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.buttonSimpan = new System.Windows.Forms.Button();
            this.dataGridViewEntryDataAnggota = new System.Windows.Forms.DataGridView();
            this.textBoxAlamat = new System.Windows.Forms.TextBox();
            this.textBoxKelas = new System.Windows.Forms.TextBox();
            this.textBoxNamaAnggota = new System.Windows.Forms.TextBox();
            this.textBoxKodeAnggota = new System.Windows.Forms.TextBox();
            this.labelAlamat = new System.Windows.Forms.Label();
            this.labelKelas = new System.Windows.Forms.Label();
            this.labelNamaAnggota = new System.Windows.Forms.Label();
            this.labelKodeAnggota = new System.Windows.Forms.Label();
            this.groupBoxAnggota.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEntryDataAnggota)).BeginInit();
            this.SuspendLayout();
            // 
            // labelAnggota
            // 
            this.labelAnggota.AutoSize = true;
            this.labelAnggota.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAnggota.Location = new System.Drawing.Point(479, 25);
            this.labelAnggota.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelAnggota.Name = "labelAnggota";
            this.labelAnggota.Size = new System.Drawing.Size(248, 24);
            this.labelAnggota.TabIndex = 0;
            this.labelAnggota.Text = "ENTRY DATA ANGGOTA";
            // 
            // groupBoxAnggota
            // 
            this.groupBoxAnggota.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBoxAnggota.Controls.Add(this.buttonDelete);
            this.groupBoxAnggota.Controls.Add(this.buttonUpdate);
            this.groupBoxAnggota.Controls.Add(this.buttonSimpan);
            this.groupBoxAnggota.Controls.Add(this.dataGridViewEntryDataAnggota);
            this.groupBoxAnggota.Controls.Add(this.textBoxAlamat);
            this.groupBoxAnggota.Controls.Add(this.textBoxKelas);
            this.groupBoxAnggota.Controls.Add(this.textBoxNamaAnggota);
            this.groupBoxAnggota.Controls.Add(this.textBoxKodeAnggota);
            this.groupBoxAnggota.Controls.Add(this.labelAlamat);
            this.groupBoxAnggota.Controls.Add(this.labelKelas);
            this.groupBoxAnggota.Controls.Add(this.labelNamaAnggota);
            this.groupBoxAnggota.Controls.Add(this.labelKodeAnggota);
            this.groupBoxAnggota.Location = new System.Drawing.Point(32, 63);
            this.groupBoxAnggota.Margin = new System.Windows.Forms.Padding(4);
            this.groupBoxAnggota.Name = "groupBoxAnggota";
            this.groupBoxAnggota.Padding = new System.Windows.Forms.Padding(4);
            this.groupBoxAnggota.Size = new System.Drawing.Size(1133, 450);
            this.groupBoxAnggota.TabIndex = 1;
            this.groupBoxAnggota.TabStop = false;
            this.groupBoxAnggota.Text = "Data Anggota";
            // 
            // buttonDelete
            // 
            this.buttonDelete.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.buttonDelete.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonDelete.Location = new System.Drawing.Point(229, 190);
            this.buttonDelete.Margin = new System.Windows.Forms.Padding(4);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(100, 39);
            this.buttonDelete.TabIndex = 14;
            this.buttonDelete.Text = "Delete";
            this.buttonDelete.UseVisualStyleBackColor = false;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.buttonUpdate.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonUpdate.Location = new System.Drawing.Point(121, 190);
            this.buttonUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(100, 39);
            this.buttonUpdate.TabIndex = 13;
            this.buttonUpdate.Text = "Update";
            this.buttonUpdate.UseVisualStyleBackColor = false;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // buttonSimpan
            // 
            this.buttonSimpan.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonSimpan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.buttonSimpan.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonSimpan.Location = new System.Drawing.Point(13, 190);
            this.buttonSimpan.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSimpan.Name = "buttonSimpan";
            this.buttonSimpan.Size = new System.Drawing.Size(100, 39);
            this.buttonSimpan.TabIndex = 12;
            this.buttonSimpan.Text = "Simpan";
            this.buttonSimpan.UseVisualStyleBackColor = false;
            this.buttonSimpan.Click += new System.EventHandler(this.buttonSimpan_Click);
            // 
            // dataGridViewEntryDataAnggota
            // 
            this.dataGridViewEntryDataAnggota.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.dataGridViewEntryDataAnggota.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEntryDataAnggota.Location = new System.Drawing.Point(13, 247);
            this.dataGridViewEntryDataAnggota.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewEntryDataAnggota.Name = "dataGridViewEntryDataAnggota";
            this.dataGridViewEntryDataAnggota.RowHeadersWidth = 51;
            this.dataGridViewEntryDataAnggota.Size = new System.Drawing.Size(1109, 196);
            this.dataGridViewEntryDataAnggota.TabIndex = 8;
            this.dataGridViewEntryDataAnggota.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // textBoxAlamat
            // 
            this.textBoxAlamat.Location = new System.Drawing.Point(189, 140);
            this.textBoxAlamat.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAlamat.Name = "textBoxAlamat";
            this.textBoxAlamat.Size = new System.Drawing.Size(920, 22);
            this.textBoxAlamat.TabIndex = 7;
            // 
            // textBoxKelas
            // 
            this.textBoxKelas.Location = new System.Drawing.Point(189, 106);
            this.textBoxKelas.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxKelas.Name = "textBoxKelas";
            this.textBoxKelas.Size = new System.Drawing.Size(920, 22);
            this.textBoxKelas.TabIndex = 6;
            // 
            // textBoxNamaAnggota
            // 
            this.textBoxNamaAnggota.Location = new System.Drawing.Point(189, 73);
            this.textBoxNamaAnggota.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxNamaAnggota.Name = "textBoxNamaAnggota";
            this.textBoxNamaAnggota.Size = new System.Drawing.Size(920, 22);
            this.textBoxNamaAnggota.TabIndex = 5;
            // 
            // textBoxKodeAnggota
            // 
            this.textBoxKodeAnggota.Location = new System.Drawing.Point(189, 39);
            this.textBoxKodeAnggota.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxKodeAnggota.Name = "textBoxKodeAnggota";
            this.textBoxKodeAnggota.Size = new System.Drawing.Size(920, 22);
            this.textBoxKodeAnggota.TabIndex = 4;
            // 
            // labelAlamat
            // 
            this.labelAlamat.AutoSize = true;
            this.labelAlamat.Location = new System.Drawing.Point(12, 144);
            this.labelAlamat.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelAlamat.Name = "labelAlamat";
            this.labelAlamat.Size = new System.Drawing.Size(51, 17);
            this.labelAlamat.TabIndex = 3;
            this.labelAlamat.Text = "Alamat";
            // 
            // labelKelas
            // 
            this.labelKelas.AutoSize = true;
            this.labelKelas.Location = new System.Drawing.Point(9, 112);
            this.labelKelas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelKelas.Name = "labelKelas";
            this.labelKelas.Size = new System.Drawing.Size(43, 17);
            this.labelKelas.TabIndex = 2;
            this.labelKelas.Text = "Kelas";
            // 
            // labelNamaAnggota
            // 
            this.labelNamaAnggota.AutoSize = true;
            this.labelNamaAnggota.Location = new System.Drawing.Point(9, 78);
            this.labelNamaAnggota.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelNamaAnggota.Name = "labelNamaAnggota";
            this.labelNamaAnggota.Size = new System.Drawing.Size(102, 17);
            this.labelNamaAnggota.TabIndex = 1;
            this.labelNamaAnggota.Text = "Nama Anggota";
            // 
            // labelKodeAnggota
            // 
            this.labelKodeAnggota.AutoSize = true;
            this.labelKodeAnggota.Location = new System.Drawing.Point(9, 42);
            this.labelKodeAnggota.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelKodeAnggota.Name = "labelKodeAnggota";
            this.labelKodeAnggota.Size = new System.Drawing.Size(98, 17);
            this.labelKodeAnggota.TabIndex = 0;
            this.labelKodeAnggota.Text = "Kode Anggota";
            // 
            // EntryDataAnggota
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1200, 543);
            this.Controls.Add(this.groupBoxAnggota);
            this.Controls.Add(this.labelAnggota);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "EntryDataAnggota";
            this.Text = "FormKelolaAnggota";
            this.Load += new System.EventHandler(this.EntryDataAnggota_Load);
            this.groupBoxAnggota.ResumeLayout(false);
            this.groupBoxAnggota.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEntryDataAnggota)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelAnggota;
        private System.Windows.Forms.GroupBox groupBoxAnggota;
        private System.Windows.Forms.DataGridView dataGridViewEntryDataAnggota;
        private System.Windows.Forms.TextBox textBoxAlamat;
        private System.Windows.Forms.TextBox textBoxKelas;
        private System.Windows.Forms.TextBox textBoxNamaAnggota;
        private System.Windows.Forms.TextBox textBoxKodeAnggota;
        private System.Windows.Forms.Label labelAlamat;
        private System.Windows.Forms.Label labelKelas;
        private System.Windows.Forms.Label labelNamaAnggota;
        private System.Windows.Forms.Label labelKodeAnggota;
        private System.Windows.Forms.Button buttonSimpan;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.Button buttonDelete;
    }
}