﻿
namespace WindowsFormsPerpustakaan
{
    partial class FormKelolaBuku
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelBuku = new System.Windows.Forms.Label();
            this.groupBoxAnggota = new System.Windows.Forms.GroupBox();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.buttonSimpan = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.labelThnTerbit = new System.Windows.Forms.Label();
            this.dataGridViewDataBuku = new System.Windows.Forms.DataGridView();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.labelPenerbit = new System.Windows.Forms.Label();
            this.labelPengarang = new System.Windows.Forms.Label();
            this.labeljdlbuku = new System.Windows.Forms.Label();
            this.labelKodeBuku = new System.Windows.Forms.Label();
            this.groupBoxAnggota.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDataBuku)).BeginInit();
            this.SuspendLayout();
            // 
            // labelBuku
            // 
            this.labelBuku.AutoSize = true;
            this.labelBuku.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBuku.Location = new System.Drawing.Point(475, 22);
            this.labelBuku.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelBuku.Name = "labelBuku";
            this.labelBuku.Size = new System.Drawing.Size(200, 24);
            this.labelBuku.TabIndex = 1;
            this.labelBuku.Text = "ENTRY DATA BUKU";
            // 
            // groupBoxAnggota
            // 
            this.groupBoxAnggota.Controls.Add(this.buttonDelete);
            this.groupBoxAnggota.Controls.Add(this.buttonUpdate);
            this.groupBoxAnggota.Controls.Add(this.buttonSimpan);
            this.groupBoxAnggota.Controls.Add(this.textBox5);
            this.groupBoxAnggota.Controls.Add(this.labelThnTerbit);
            this.groupBoxAnggota.Controls.Add(this.dataGridViewDataBuku);
            this.groupBoxAnggota.Controls.Add(this.textBox4);
            this.groupBoxAnggota.Controls.Add(this.textBox3);
            this.groupBoxAnggota.Controls.Add(this.textBox2);
            this.groupBoxAnggota.Controls.Add(this.textBox1);
            this.groupBoxAnggota.Controls.Add(this.labelPenerbit);
            this.groupBoxAnggota.Controls.Add(this.labelPengarang);
            this.groupBoxAnggota.Controls.Add(this.labeljdlbuku);
            this.groupBoxAnggota.Controls.Add(this.labelKodeBuku);
            this.groupBoxAnggota.Location = new System.Drawing.Point(33, 59);
            this.groupBoxAnggota.Margin = new System.Windows.Forms.Padding(4);
            this.groupBoxAnggota.Name = "groupBoxAnggota";
            this.groupBoxAnggota.Padding = new System.Windows.Forms.Padding(4);
            this.groupBoxAnggota.Size = new System.Drawing.Size(1135, 457);
            this.groupBoxAnggota.TabIndex = 2;
            this.groupBoxAnggota.TabStop = false;
            this.groupBoxAnggota.Text = "Data Anggota";
            // 
            // buttonDelete
            // 
            this.buttonDelete.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.buttonDelete.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonDelete.Location = new System.Drawing.Point(232, 219);
            this.buttonDelete.Margin = new System.Windows.Forms.Padding(4);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(100, 39);
            this.buttonDelete.TabIndex = 13;
            this.buttonDelete.Text = "Delete";
            this.buttonDelete.UseVisualStyleBackColor = false;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.buttonUpdate.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonUpdate.Location = new System.Drawing.Point(124, 219);
            this.buttonUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(100, 39);
            this.buttonUpdate.TabIndex = 12;
            this.buttonUpdate.Text = "Update";
            this.buttonUpdate.UseVisualStyleBackColor = false;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // buttonSimpan
            // 
            this.buttonSimpan.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonSimpan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.buttonSimpan.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonSimpan.Location = new System.Drawing.Point(16, 219);
            this.buttonSimpan.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSimpan.Name = "buttonSimpan";
            this.buttonSimpan.Size = new System.Drawing.Size(100, 39);
            this.buttonSimpan.TabIndex = 11;
            this.buttonSimpan.Text = "Simpan";
            this.buttonSimpan.UseVisualStyleBackColor = false;
            this.buttonSimpan.Click += new System.EventHandler(this.buttonSimpan_Click_1);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(189, 174);
            this.textBox5.Margin = new System.Windows.Forms.Padding(4);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(921, 22);
            this.textBox5.TabIndex = 10;
            // 
            // labelThnTerbit
            // 
            this.labelThnTerbit.AutoSize = true;
            this.labelThnTerbit.Location = new System.Drawing.Point(12, 177);
            this.labelThnTerbit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelThnTerbit.Name = "labelThnTerbit";
            this.labelThnTerbit.Size = new System.Drawing.Size(90, 17);
            this.labelThnTerbit.TabIndex = 9;
            this.labelThnTerbit.Text = "Tahun Terbit";
            // 
            // dataGridViewDataBuku
            // 
            this.dataGridViewDataBuku.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDataBuku.Location = new System.Drawing.Point(13, 277);
            this.dataGridViewDataBuku.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewDataBuku.Name = "dataGridViewDataBuku";
            this.dataGridViewDataBuku.RowHeadersWidth = 51;
            this.dataGridViewDataBuku.Size = new System.Drawing.Size(1113, 172);
            this.dataGridViewDataBuku.TabIndex = 8;
            this.dataGridViewDataBuku.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(189, 140);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(921, 22);
            this.textBox4.TabIndex = 7;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(189, 106);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(921, 22);
            this.textBox3.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(189, 73);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(921, 22);
            this.textBox2.TabIndex = 5;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(189, 39);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(921, 22);
            this.textBox1.TabIndex = 4;
            // 
            // labelPenerbit
            // 
            this.labelPenerbit.AutoSize = true;
            this.labelPenerbit.Location = new System.Drawing.Point(12, 144);
            this.labelPenerbit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPenerbit.Name = "labelPenerbit";
            this.labelPenerbit.Size = new System.Drawing.Size(61, 17);
            this.labelPenerbit.TabIndex = 3;
            this.labelPenerbit.Text = "Penerbit";
            // 
            // labelPengarang
            // 
            this.labelPengarang.AutoSize = true;
            this.labelPengarang.Location = new System.Drawing.Point(9, 112);
            this.labelPengarang.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPengarang.Name = "labelPengarang";
            this.labelPengarang.Size = new System.Drawing.Size(78, 17);
            this.labelPengarang.TabIndex = 2;
            this.labelPengarang.Text = "Pengarang";
            // 
            // labeljdlbuku
            // 
            this.labeljdlbuku.AutoSize = true;
            this.labeljdlbuku.Location = new System.Drawing.Point(9, 78);
            this.labeljdlbuku.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labeljdlbuku.Name = "labeljdlbuku";
            this.labeljdlbuku.Size = new System.Drawing.Size(78, 17);
            this.labeljdlbuku.TabIndex = 1;
            this.labeljdlbuku.Text = "Judul Buku";
            // 
            // labelKodeBuku
            // 
            this.labelKodeBuku.AutoSize = true;
            this.labelKodeBuku.Location = new System.Drawing.Point(9, 42);
            this.labelKodeBuku.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelKodeBuku.Name = "labelKodeBuku";
            this.labelKodeBuku.Size = new System.Drawing.Size(77, 17);
            this.labelKodeBuku.TabIndex = 0;
            this.labelKodeBuku.Text = "Kode Buku";
            // 
            // FormKelolaBuku
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1200, 543);
            this.Controls.Add(this.groupBoxAnggota);
            this.Controls.Add(this.labelBuku);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormKelolaBuku";
            this.Text = "FormKelolaBuku";
            this.groupBoxAnggota.ResumeLayout(false);
            this.groupBoxAnggota.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDataBuku)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelBuku;
        private System.Windows.Forms.GroupBox groupBoxAnggota;
        private System.Windows.Forms.DataGridView dataGridViewDataBuku;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label labelPenerbit;
        private System.Windows.Forms.Label labelPengarang;
        private System.Windows.Forms.Label labeljdlbuku;
        private System.Windows.Forms.Label labelKodeBuku;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label labelThnTerbit;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.Button buttonSimpan;
    }
}